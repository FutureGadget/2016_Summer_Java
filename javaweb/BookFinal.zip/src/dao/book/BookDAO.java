package dao.book;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import common.DBTemplate;
import entity.book.BookEntity;

public class BookDAO {
	public ArrayList<BookEntity> queryBookByName(String bookName) {
		ArrayList<BookEntity> list = new ArrayList<>();
		Connection conn = DBTemplate.getConnection();
		try {
			String sql = "SELECT bisbn, btitle, bauthor, bprice, bimgurl FROM books WHERE btitle LIKE ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+bookName+"%"); // % = cmd���� *�� ���� (% matches any number of characters, even zero characters.)
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				list.add(new BookEntity(rs.getString("bisbn"), rs.getString("btitle"), rs.getString("bauthor"), 
						rs.getString("bprice"), rs.getString("bimgurl")));
			}
			rs.close();
			pstmt.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}
